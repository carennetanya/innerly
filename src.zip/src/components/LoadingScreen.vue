<template>
  <div v-if="visible" class="loading-screen">
    <div class="bg-overlay"></div>

    <!-- Full screen burst overlay -->
    <div class="burst-overlay" :class="{ active: phase >= 6 }"></div>

    <div class="stage">
      <div class="ripple ripple-1" :class="{ active: phase >= 2 }"></div>
      <div class="ripple ripple-2" :class="{ active: phase >= 2 }"></div>

      <template v-if="showSparks1">
        <div
          v-for="i in 20"
          :key="'s' + i"
          class="spark"
          :style="getSparkStyle(i, 20)"
        ></div>
      </template>
      <template v-if="showSparks2">
        <div
          v-for="i in 18"
          :key="'b' + i"
          class="spark spark-burst"
          :style="getSparkStyle(i, 18)"
        ></div>
      </template>

      <div class="portal" :class="portalClass"></div>

      <div class="logo-wrapper" :class="{ revealed: phase >= 3 }">
        <img src="/logo.png" alt="Cadara Logo" class="logo-img" />
        <div
          class="star-glow"
          :class="{ grow: phase >= 5, burst: phase >= 6 }"
        ></div>
      </div>
    </div>

    <div class="brand" :class="{ visible: phase >= 4, hide: phase >= 6 }">
      <!-- pakai wrapper buat lighting, bukan langsung di gradient text -->
      <div class="brand-text-wrap" :class="{ sweep: phase >= 4 }">
        <span class="brand-text">Innerly</span>
      </div>
      <span class="brand-tagline">Reflect deeper, grow stronger.</span>
    </div>
  </div>
</template>

<script setup>
import { ref, computed, onMounted } from "vue";

const visible = ref(true);
const phase = ref(0);
const showSparks1 = ref(false);
const showSparks2 = ref(false);

const portalClass = computed(() => {
  if (phase.value >= 3) return "phase-hold";
  if (phase.value >= 2) return "phase-expand";
  if (phase.value >= 1) return "phase-appear";
  return "";
});

function getSparkStyle(i, total) {
  const angle = (i / total) * 360;
  const delay = (i / total) * 0.45;
  const dist = 110 + (i % 4) * 18;
  return {
    "--angle": `${angle}deg`,
    "--dist": `${dist}px`,
    animationDelay: `${delay}s`,
  };
}

onMounted(() => {
  setTimeout(() => {
    phase.value = 1;
  }, 300);

  setTimeout(() => {
    phase.value = 2;
    showSparks1.value = true;
    setTimeout(() => {
      showSparks1.value = false;
    }, 1200);
  }, 900);

  setTimeout(() => {
    phase.value = 3;
    showSparks2.value = true;
    setTimeout(() => {
      showSparks2.value = false;
    }, 1200);
  }, 2700);

  setTimeout(() => {
    phase.value = 4;
  }, 3400);
  setTimeout(() => {
    phase.value = 5;
  }, 5500); // bintang kecil mulai tumbuh
  setTimeout(() => {
    phase.value = 6;
  }, 6400); // full screen burst
  setTimeout(() => {
    visible.value = false;
  }, 7500);
});
</script>

<style scoped>
@import url("https://fonts.googleapis.com/css2?family=Orbitron:wght@400;700;900&family=Outfit:wght@300;400&display=swap");

.loading-screen {
  position: fixed;
  inset: 0;
  background: radial-gradient(
    ellipse at 50% 40%,
    #0d1a27 0%,
    #060c12 60%,
    #020609 100%
  );
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  z-index: 9999;
  overflow: hidden;
}

.bg-overlay {
  position: absolute;
  inset: 0;
  background-image: url("data:image/svg+xml,%3Csvg viewBox='0 0 200 200' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23n)' opacity='0.04'/%3E%3C/svg%3E");
  background-size: 200px 200px;
  pointer-events: none;
}

/* ── Burst overlay — bintang 4 ujung kayak di logo ── */
.burst-overlay {
  position: absolute;
  z-index: 20;
  pointer-events: none;
  width: 30px;
  height: 30px;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%) scale(0) rotate(0deg);
  opacity: 0;
  background: radial-gradient(
    ellipse at center,
    #ffffff 0%,
    #e0f8ff 25%,
    #22d3ee 55%,
    #0891b2 85%
  );
  clip-path: polygon(
    50% 0%,
    58% 42%,
    100% 50%,
    58% 58%,
    50% 100%,
    42% 58%,
    0% 50%,
    42% 42%
  );
}
.burst-overlay.active {
  animation: burstExpand 1.1s cubic-bezier(0.15, 0.8, 0.3, 1) forwards;
}
@keyframes burstExpand {
  0% {
    opacity: 0;
    transform: translate(-50%, -50%) scale(0) rotate(0deg);
    clip-path: polygon(
      50% 0%,
      58% 42%,
      100% 50%,
      58% 58%,
      50% 100%,
      42% 58%,
      0% 50%,
      42% 42%
    );
  }
  6% {
    opacity: 1;
    transform: translate(-50%, -50%) scale(2) rotate(10deg);
  }
  40% {
    opacity: 1;
    transform: translate(-50%, -50%) scale(25) rotate(25deg);
    clip-path: polygon(
      50% 0%,
      58% 42%,
      100% 50%,
      58% 58%,
      50% 100%,
      42% 58%,
      0% 50%,
      42% 42%
    );
  }
  100% {
    opacity: 1;
    transform: translate(-50%, -50%) scale(160) rotate(45deg);
    clip-path: polygon(
      50% 10%,
      53% 47%,
      90% 50%,
      53% 53%,
      50% 90%,
      47% 53%,
      10% 50%,
      47% 47%
    );
  }
}

/* ── Stage ── */
.stage {
  position: relative;
  width: 300px;
  height: 300px;
  display: flex;
  align-items: center;
  justify-content: center;
}

/* ── Ripples ── */
.ripple {
  position: absolute;
  border-radius: 50%;
  border: 1px solid rgba(0, 194, 224, 0.15);
  opacity: 0;
  pointer-events: none;
}
.ripple-1 {
  width: 250px;
  height: 250px;
}
.ripple-2 {
  width: 330px;
  height: 330px;
}
.ripple.active {
  animation: rippleAnim 2s ease-out forwards;
}
.ripple-2.active {
  animation: rippleAnim 2s ease-out 0.3s forwards;
}
@keyframes rippleAnim {
  0% {
    opacity: 0;
    transform: scale(0.4);
  }
  25% {
    opacity: 0.5;
  }
  100% {
    opacity: 0;
    transform: scale(1.6);
  }
}

/* ── Sparks ── */
.spark {
  position: absolute;
  width: 3px;
  height: 3px;
  border-radius: 50%;
  background: #00c2e0;
  box-shadow: 0 0 6px 2px rgba(0, 194, 224, 0.9);
  opacity: 0;
  animation: sparkFly 0.8s ease-out forwards;
}
.spark:nth-child(3n) {
  background: #0a7bff;
  box-shadow: 0 0 6px 2px rgba(10, 123, 255, 0.9);
  width: 4px;
  height: 4px;
}
.spark:nth-child(3n + 1) {
  background: #a8e63d;
  box-shadow: 0 0 6px 2px rgba(168, 230, 61, 0.9);
}
.spark-burst {
  width: 4px;
  height: 4px;
  animation-duration: 1s;
}
.spark-burst:nth-child(3n) {
  width: 5px;
  height: 5px;
}
@keyframes sparkFly {
  0% {
    opacity: 0;
    transform: rotate(var(--angle)) translateX(50px) scale(1.2);
  }
  15% {
    opacity: 1;
  }
  100% {
    opacity: 0;
    transform: rotate(var(--angle)) translateX(var(--dist)) scale(0.1);
  }
}

/* ── Portal ring ── */
.portal {
  position: absolute;
  border-radius: 50%;
  pointer-events: none;
  background: conic-gradient(
    from 0deg,
    #0a7bff 0%,
    #00c2e0 25%,
    #a8e63d 50%,
    #00c2e0 75%,
    #0a7bff 100%
  );
  -webkit-mask-image: radial-gradient(circle, transparent 72%, black 75%);
  mask-image: radial-gradient(circle, transparent 72%, black 75%);
  width: 0;
  height: 0;
  opacity: 0;
}
.portal.phase-appear {
  animation: portalAppear 0.5s cubic-bezier(0.34, 1.56, 0.64, 1) forwards;
}
@keyframes portalAppear {
  to {
    width: 30px;
    height: 30px;
    opacity: 1;
  }
}
.portal.phase-expand {
  animation: portalSpinExpand 1.7s cubic-bezier(0.25, 0.8, 0.35, 1) forwards;
}
@keyframes portalSpinExpand {
  0% {
    width: 30px;
    height: 30px;
    opacity: 1;
    transform: rotate(0deg);
  }
  40% {
    width: 100px;
    height: 100px;
    transform: rotate(200deg);
  }
  100% {
    width: 210px;
    height: 210px;
    opacity: 1;
    transform: rotate(540deg);
    box-shadow:
      0 0 40px 10px rgba(0, 194, 224, 0.3),
      0 0 80px 20px rgba(10, 123, 255, 0.12);
  }
}
.portal.phase-hold {
  animation: portalIdleSpin 6s linear infinite;
  width: 210px;
  height: 210px;
  opacity: 1;
  box-shadow:
    0 0 40px 10px rgba(0, 194, 224, 0.3),
    0 0 80px 20px rgba(10, 123, 255, 0.12);
}
@keyframes portalIdleSpin {
  from {
    transform: rotate(0deg);
  }
  to {
    transform: rotate(360deg);
  }
}

/* ── Logo ── */
.logo-wrapper {
  position: absolute;
  width: 0;
  height: 0;
  opacity: 0;
  display: flex;
  align-items: center;
  justify-content: center;
}
.logo-wrapper.revealed {
  animation: logoReveal 0.7s cubic-bezier(0.34, 1.2, 0.64, 1) forwards;
}
@keyframes logoReveal {
  0% {
    width: 0;
    height: 0;
    opacity: 0;
  }
  30% {
    opacity: 1;
  }
  100% {
    width: 220px;
    height: 220px;
    opacity: 1;
    filter: drop-shadow(0 0 14px rgba(0, 194, 224, 0.55))
      drop-shadow(0 0 32px rgba(10, 123, 255, 0.25));
  }
}
.logo-img {
  width: 100%;
  height: 100%;
  object-fit: contain;
  mix-blend-mode: lighten;
}

/* ── Star glow — di posisi bintang logo ── */
.star-glow {
  position: absolute;
  top: 28%;
  left: 50%;
  transform: translateX(-50%) scale(0);
  width: 8px;
  height: 8px;
  border-radius: 50%;
  background: #fff;
  box-shadow: 0 0 6px 3px rgba(220, 245, 255, 0.9);
  opacity: 0;
  pointer-events: none;
}
/* phase 5: bintang kecil muncul lalu membesar pelan */
.star-glow.grow {
  animation: starGrow 0.9s ease-out forwards;
}
@keyframes starGrow {
  0% {
    opacity: 0;
    transform: translateX(-50%) scale(0);
  }
  15% {
    opacity: 1;
    transform: translateX(-50%) scale(1);
    box-shadow: 0 0 8px 4px rgba(200, 240, 255, 1);
  }
  60% {
    opacity: 1;
    transform: translateX(-50%) scale(3);
    box-shadow: 0 0 20px 10px rgba(200, 240, 255, 0.9);
  }
  100% {
    opacity: 1;
    transform: translateX(-50%) scale(6);
    box-shadow: 0 0 35px 18px rgba(200, 240, 255, 0.7);
  }
}
/* phase 6: bintang meledak, digantikan burst overlay */
.star-glow.burst {
  animation:
    starGrow 0s forwards,
    starFadeOut 0.3s ease-out forwards;
}
@keyframes starFadeOut {
  0% {
    opacity: 1;
    transform: translateX(-50%) scale(6);
  }
  100% {
    opacity: 0;
    transform: translateX(-50%) scale(20);
  }
}

/* ── Brand ── */
.brand {
  margin-top: 16px;
  text-align: center;
  opacity: 0;
  transform: translateY(10px);
  transition:
    opacity 0.4s ease,
    transform 0.4s ease;
}
.brand.visible {
  opacity: 1;
  transform: translateY(0);
}
.brand.hide {
  opacity: 0 !important;
  transform: translateY(-16px) !important;
  transition:
    opacity 0.3s ease,
    transform 0.3s ease;
}

/* wrapper untuk lighting effect — TIDAK pakai gradient text langsung */
.brand-text-wrap {
  display: inline-block;
}
.brand-text-wrap.sweep {
  animation: wrapSweep 1.8s ease both;
  animation-delay: 0.1s;
}
@keyframes wrapSweep {
  0% {
    opacity: 0.3;
    transform: scale(0.96);
    letter-spacing: normal;
  }
  40% {
    filter: drop-shadow(0 0 18px rgba(0, 194, 224, 0.95))
      drop-shadow(0 0 35px rgba(10, 123, 255, 0.7));
    transform: scale(1.03);
  }
  100% {
    filter: drop-shadow(0 0 6px rgba(0, 194, 224, 0.35));
    transform: scale(1);
    opacity: 1;
  }
}

/* gradient text — tanpa filter supaya tidak conflict */
.brand-text {
  display: block;
  font-family: "Orbitron", sans-serif;
  font-weight: 900;
  font-size: 2rem;
  letter-spacing: 0.35em;
  background: linear-gradient(90deg, #00c2e0 0%, #0a7bff 50%, #a8e63d 100%);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  background-clip: text;
}

.brand-tagline {
  display: block;
  font-family: "Outfit", sans-serif;
  font-weight: 300;
  font-size: 0.72rem;
  letter-spacing: 0.22em;
  color: rgba(168, 230, 61, 0.55);
  margin-top: 6px;
  text-transform: uppercase;
}
</style>
