<template>
  <LoadingScreen v-if="isLoading" />
  <div v-else>
    <!-- konten website nanti di sini -->
  </div>
</template>

<script setup>
import { ref } from "vue";
import LoadingScreen from "./components/LoadingScreen.vue";

const isLoading = ref(true);

// harus sama atau lebih dari durasi loading screen
setTimeout(() => {
  isLoading.value = false;
}, 7600);
</script>
